<?php

namespace App\Services\WhatsApp;

use Illuminate\Support\Facades\Log;

class WhatsAppApiService{
	protected string $accessToken;
	protected string $phoneNumberId;
	protected string $baseUrl = 'https://graph.facebook.com/v19.0';

	public function __construct(string $accessToken, string $phoneNumberId)
	{
		$this->accessToken   = $accessToken;
		$this->phoneNumberId = $phoneNumberId;
	}
	public static function request(string $url,string $accessToken,array $payload = [],string $method = 'POST',array $headers = [] ): array {
		$ch = curl_init($url);
		$defaultHeaders = [
			'Authorization: Bearer ' . $accessToken,
			'Content-Type: application/json',
		];
		$options = [
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_TIMEOUT        => 30,
			CURLOPT_HTTPHEADER     => array_merge($defaultHeaders, $headers),
		];
		switch (strtoupper($method)) {
		case 'POST':
			$options[CURLOPT_POST] = true;
			$options[CURLOPT_POSTFIELDS] = json_encode($payload);
			break;

		case 'PUT':
		case 'PATCH':
			$options[CURLOPT_CUSTOMREQUEST] = $method;
			$options[CURLOPT_POSTFIELDS] = json_encode($payload);
			break;

		case 'GET':
			if (!empty($payload)) {
				$url .= '?' . http_build_query($payload);
				curl_setopt($ch, CURLOPT_URL, $url);
			}
			break;

		case 'DELETE':
			$options[CURLOPT_CUSTOMREQUEST] = 'DELETE';
			break;
		}
		curl_setopt_array($ch, $options);
		$response = curl_exec($ch);
		$error    = curl_error($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);

		if ($error) {
			return [
				'success' => false,
				'error'   => $error,
			];
		}

		return [
			'success'   => $httpCode < 400,
			'http_code' => $httpCode,
			'response'  => json_decode($response, true),
			'raw'       => $response,
		];
	}
	public function sendTextMessage(string $to, string $message){
		$payload = [
			'messaging_product' => 'whatsapp',
			'to' => $to,
			'type' => 'text',
			'text' => [
				'body' => $message
			]
		];
		return self::request("{$this->phoneNumberId}/messages",$payload);
	}
	public function sendTemplateMessage(string $to,string $templateName,string $language = 'en_US',array $components = [] ): array 
	{	
		$url = "{$this->baseUrl}/{$this->phoneNumberId}/messages";
		$payload = [
			'messaging_product' => 'whatsapp',
			'to'   => $to,
			'type' => 'template',
			'template' => [
				'name'     => $templateName,
				'language' => [
					'code' => $language
				]
			]
		];
		if (!empty($components)) {
			$payload['template']['components'] = $components;
		}

		return self::request($url,$this->accessToken,$payload,'POST');
	}
	public function getTemplates(string $businessId): array 
	{
		$url = "https://graph.facebook.com/v22.0/{$businessId}/message_templates";
		return self::request(
			$url,
			$this->accessToken,
			[],
			'GET'
		);
	}
}

