<?php

namespace App\Modules\Api\V1\WhatsApp\Controllers;

use App\Modules\Api\V1\WhatsApp\Models\WhatsAppTemplateFieldMapping;
use App\Http\Controllers\Controller;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Models\FieldModelManager;
use App\Services\WhatsApp\WhatsAppApiService;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppOrgRel;


class TemplateController extends Controller{
	public function index()
	{
		return response()->json([
			'templates' => []
		]);
	}

	public function show($name)
	{
		return response()->json([
			'template_name' => $name,
			'status' => 'approved'
		]);
	}
	public function getWhatsAppTemplates(Request $request)
	{
		$data = $request->input('data.values', []);
		if (empty($data['organization_id'])) {
			return response()->json([
				'status' => false,
				'message' => 'organization_id required'
			], 422);
		}

		$config = WhatsAppOrgRel::where(
			'organization_id',
			$data['organization_id']
		)->firstOrFail();
		

		$service = new WhatsAppApiService(
			$config->access_token,
			$config->phone_number_id
		);

		$response = $service->getTemplates($config->business_id);
		dd($response);

		return response()->json([
			'data' => [
				'values' => $response['response']['data'] ?? []
			]
		]);
	}
	public function getMappingTemplates(Request $request){

		$organizationId = $request->get('organization_id');

		$templates = WhatsAppTemplateFieldMapping::where(
			'organization_id',
			$organizationId
		)->get();

		$values = $templates->map(function ($row) {
			return [
				'id'                => $row->id,
				'template_name'     => $row->template_name,
				'language'          => $row->template_language,
				'template_variable' => $row->template_variable,
				'crm_module'        => $row->crm_module,
				'crm_field'         => $row->crm_field,
			];
		});

		return response()->json([
			'data' => [
				'values' => $values
			]
		]);
	}

	public function save(Request $request, string $id = null){
		$data = $request->input('data.values', []);

		// Basic validation
		if (empty($data['organization_id']) || empty($data['template_name'])) {
			return response()->json([
				'status' => false,
				'message' => 'organization_id and template_name are required'
			], 422);
		}

		if (empty($data['mappings']) || !is_array($data['mappings'])) {
			return response()->json([
				'status' => false,
				'message' => 'Mappings are required'
			], 422);
		}

		// Validate CRM module & fields before saving
		 
		foreach ($data['mappings'] as $map) {

			if (empty($map['crm_module']) || empty($map['crm_field']) || empty($map['template_variable']) ) {
				return response()->json([
					'status' => false,
					'message' => 'Invalid mapping data'
				], 422);
			}

			//  CRM FIELD VALIDATION (your existing CRM way)
			try {
				$fieldManager = FieldModelManager::make(
					$map['crm_module'],
					'DetailView'
				);

				$fields = $fieldManager->getFields();

				if (!isset($fields[$map['crm_field']])) {
					return response()->json([
						'status' => false,
						'message' => "Field {$map['crm_field']} not found in module {$map['crm_module']}"
					], 422);
				}

			} catch (\Throwable $e) {
				return response()->json([
					'status' => false,
					'message' => "Invalid CRM module: {$map['crm_module']}"
				], 422);
			}
		}


		foreach ($data['mappings'] as $mapping) {

			if ($id && $id !== 'new') {

				// UPDATE case
				$record = WhatsAppTemplateFieldMapping::where('id', $id)
					->where('template_variable', $mapping['template_variable'])
					->first();

				if ($record) {
					$record->update([
						'crm_module' => $mapping['crm_module'],
						'crm_field'  => $mapping['crm_field'],
					]);
				}

			} else {

				//  CREATE case
				WhatsAppTemplateFieldMapping::create([
					'id'                => (string) Str::uuid(),
					'organization_id'   => $data['organization_id'],
					'template_name'     => $data['template_name'],
					'template_language' => $data['language'],
					'template_variable' => $mapping['template_variable'],
					'crm_module'        => $mapping['crm_module'],
					'crm_field'         => $mapping['crm_field'],
				]);
			}
		}

		return response()->json([
			'status'  => true,
			'message' => $isUpdate ? 'Template mapping updated' : 'Template mapping created'
		]);
	}
}
