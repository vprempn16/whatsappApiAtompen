<?php

namespace App\Modules\Api\V1\WhatsApp\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Carbon\Carbon;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppConversation;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppMessage;

class WebhookController extends Controller{
	public function incomingMessage(Request $request){
		$payload = $request->all();

		$entry = $payload['entry'][0]['changes'][0]['value'] ?? null;

		if (!$entry || empty($entry['messages'][0])) {
			return response()->json(['status' => 'ignored']);
		}

		$messageData = $entry['messages'][0];

		$phoneNumber = $messageData['from'];
		$messageType = $messageData['type'];
		$messageText = $messageData['text']['body'] ?? null;

		/**
		 * TEMP:
		 * organization_id should come from whatsapp_org_rel
		 * For now, hardcode or resolve from token
		 */
		$organizationId = auth()->user()->organization_id;
		/**
		 * 1️⃣ Find or create conversation
		 */
		$conversation = WhatsAppConversation::where([
			'organization_id' => $organizationId,
			'phone_number'    => $phoneNumber,
			'deleted'         => 0,
		])->first();

		if (!$conversation) {
			$conversation = WhatsAppConversation::create([
				'id'               => (string) Str::uuid(),
				'organization_id'  => $organizationId,
				'conversation_id'  => $phoneNumber, // temp mapping
				'phone_number'     => $phoneNumber,
				'status'           => 'open',
				'last_message_at'  => Carbon::now(),
				'created_by'       => null,
			]);
		} else {
			$conversation->update([
				'last_message_at' => Carbon::now(),
			]);
		}

		/**
		 * 2️⃣ Save message
		 */
		WhatsAppMessage::create([
			'id'               => (string) Str::uuid(),
			'organization_id'  => $organizationId,
			'message_id'       => $messageData['id'] ?? null,
			'direction'        => 'incoming',
			'type'             => $messageType,
			'message'          => $messageText,
			'status'           => 'received',
			'created_by'       => null,
		]);

		return response()->json(['received' => true]);
	}

	public function messageStatus(Request $request)
	{
		return response()->json(['status_updated' => true]);
	}

	public function optOut(Request $request)
	{
		return response()->json(['opted_out' => true]);
	}
    //
}
