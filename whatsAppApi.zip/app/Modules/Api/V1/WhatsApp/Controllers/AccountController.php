<?php


namespace App\Modules\Api\V1\WhatsApp\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;


class AccountController extends Controller
{
	public function accountsInfo()
	{
		return response()->json([
			'business_name'   => 'Demo Business',
			'whatsapp_number' => '+91XXXXXXXXXX',
			'waba_status'     => 'APPROVED'
		]);
	}

	public function healthCheck()
	{
		return response()->json([
			'status' => 'ok',
			'token_valid' => true
		]);
	}
	
}
