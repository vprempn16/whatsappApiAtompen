<?php

namespace App\Modules\Api\V1\WhatsApp\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Services\WhatsApp\WhatsAppApiService;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppOrgRel;

class MessageController extends Controller{
	public function sendTextMessage(Request $request){
		$request->validate([
			'organization_id' => 'required|string',
			'to'              => 'required|string',
			'message'         => 'required|string',
		]);

		$config = WhatsAppOrgRel::where(
			'organization_id',
			$request->organization_id
		)->first();

		if (!$config) {
			return response()->json([
				'status'  => false,
				'message' => 'WhatsApp config not found'
			], 404);
		}

		// ✅ Use Service class
		$whatsAppService = new WhatsAppApiService(
			$config->access_token,
			$config->phone_number_id
		);

		$result = $whatsAppService->sendTextMessage(
			$request->to,
			$request->message
		);

		return response()->json($result);
	}

	public function sendMedia(Request $request)
	{
		$request->validate([
			'conversation_id' => 'required',
			'media_type' => 'required',
			'media_url' => 'required|url'
		]);

		return response()->json([
			'status' => 'sent',
			'media_type' => $request->media_type
		]);
	}

	public function sendTemplate(Request $request){
		$request->validate([
			'organization_id' => 'required|string',
			'to'              => 'required|string',
			'template_name'   => 'required|string',
			'language'        => 'required|string',
			'components'      => 'nullable|array',
		]);
		$config = WhatsAppOrgRel::where(
			'organization_id',
			$request->organization_id
		)->first();
		if (!$config) {
			return response()->json([
				'status'  => false,
				'message' => 'WhatsApp configuration not found'
			], 404);
		}
		$whatsAppService = new WhatsAppApiService($config->access_token,$config->phone_number_id);

		$result = $whatsAppService->sendTemplateMessage($request->to,$request->template_name,$request->language,$request->components ?? [] );

		return response()->json($result);
	}	

	public function validateMessage(Request $request)
	{
		return response()->json([
			'valid' => true,
			'reason' => null
		]);
	}

}
