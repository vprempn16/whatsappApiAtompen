<?php

namespace App\Modules\Api\V1\WhatsApp\Models;

use Illuminate\Database\Eloquent\Model;

class WhatsAppTemplate extends Model
{
    protected $table = 'whatsapp_templates';

    protected $fillable = [
        'template_name',
        'language',
        'status',
        'components',
    ];

    protected $casts = [
        'components' => 'array',
    ];
}
