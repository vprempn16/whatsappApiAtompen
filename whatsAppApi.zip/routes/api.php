<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\FilterController;
use App\Http\Controllers\Api\GoogleAuthController;
use App\Http\Controllers\Api\OrganizationController;
use App\Http\Controllers\Api\RecordController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\V1\ProfileController;
use App\Http\Controllers\Api\V1\RoleController;

use App\Modules\Api\V1\Activity\Controllers\ActivityController;
use App\Modules\Api\V1\AISearch\Controllers\AIAlterQueryController;
use App\Modules\Api\V1\AISearch\Controllers\AIQueryController;
use App\Modules\Api\V1\Asset\Controllers\AssetController;
use App\Modules\Api\V1\AuditLog\Controllers\AuditLogController;
use App\Modules\Api\V1\Comment\Controllers\CommentController;
use App\Modules\Api\V1\GlobalSearchIndex\Controllers\GlobalSearchIndexController;
use App\Modules\Api\V1\Lead\Controllers\LeadController;
use App\Modules\Api\V1\RelatedRecords\Controllers\RelatedRecords;



use App\Modules\Api\V1\WhatsApp\Controllers\AccountController;
use App\Modules\Api\V1\WhatsApp\Controllers\ConversationController;
use App\Modules\Api\V1\WhatsApp\Controllers\MessageController;
use App\Modules\Api\V1\WhatsApp\Controllers\TemplateController;
use App\Modules\Api\V1\WhatsApp\Controllers\WebhookController;
use App\Modules\Api\V1\WhatsApp\Controllers\SecurityController;

Route::prefix('v1')->middleware('api')->group(function () {

	// Public routes
	Route::post('organization/new', [OrganizationController::class, 'store']);
	Route::post('user/new', [UserController::class, 'store']);
	Route::post('login', [AuthController::class, 'login']);
	//Route::get('login/google', [GoogleAuthController::class, 'getSigninUrl']);
	// Route::get('login/google/callback', [GoogleAuthController::class, 'handleGoogleCallback']);


	Route::middleware('auth:sanctum')->group(function () {

		Route::prefix('webhooks/whatsapp')->group(function () {
			Route::post('/messages', [WebhookController::class, 'incomingMessage']);
			Route::post('/status', [WebhookController::class, 'messageStatus']);
			Route::post('/optout', [WebhookController::class, 'optOut']);
		});

		Route::prefix('whatsapp')->group(function () {
			Route::get('/account-info', [AccountController::class, 'accountsInfo']);
			Route::get('/health', [AccountController::class, 'healthCheck']);

			Route::get('/conversations', [ConversationController::class, 'index']);
			Route::get('/conversations/getConversation/{id}', [ConversationController::class, 'getConversation']);
			Route::get('/conversations/{id}', [ConversationController::class, 'show']);
			Route::post('/conversations/{id}/assign', [ConversationController::class, 'assign']);
			Route::post('/conversations/{id}/status', [ConversationController::class, 'updateStatus']);
			Route::get('/conversations/{id}/window', [ConversationController::class, 'checkWindow']);


			// Messages
			Route::post('/messages/send-message', [MessageController::class, 'sendTextMessage']);
			Route::post('/messages/send-media', [MessageController::class, 'sendMedia']);
			Route::post('/messages/send-template', [MessageController::class, 'sendTemplate']);
			Route::post('/messages/validate', [MessageController::class, 'validateMessage']);

			// Templates
			Route::get('/templates', [TemplateController::class, 'getWhatsAppTemplates']);
			Route::get('/templates/{name}', [TemplateController::class, 'show']);
			Route::post('/templates/field-mapping/new',[TemplateController::class, 'save']);
			Route::put('/templates/field-mapping/{id}',[TemplateController::class, 'save']);
			// Security
			Route::post('/security/rotate-token', [SecurityController::class, 'rotateToken']);


		});
		Route::post('filter/{module}', [GlobalSearchIndexController::class, 'filter']);

		Route::prefix('settings')->group(function () {

			// Roles
			Route::get('roles', [RoleController::class, 'index']);
			Route::post('roles', [RoleController::class, 'store']);
			Route::post('roles/profile/relate', [RoleController::class, 'relateProfiles']);
			Route::post('roles/user/relate', [RoleController::class, 'relateUser']);
			Route::delete('roles/{id}', [RoleController::class, 'destroy']);

			// Profiles
			Route::put('profile/save-full', [ProfileController::class, 'saveAll']);
			Route::get('get_profiles', [ProfileController::class, 'index']);
			Route::post('profile', [ProfileController::class, 'store']);
			Route::get('profile/info', [ProfileController::class, 'profileModuleFields']);
			Route::get('profile/{id}/details', [ProfileController::class, 'details']);
			Route::post('profile_fields', [ProfileController::class, 'profile_fields']);
			Route::post('profile_global_actions', [ProfileController::class, 'profile_global_actions']);
			Route::post('profile_module', [ProfileController::class, 'profile_module']);
			Route::post('global_actions', [ProfileController::class, 'global_actions']);
			Route::get('profile/{module}/fields', [ProfileController::class, 'profileModuleFields']);
			Route::get('profile/modules', [ProfileController::class, 'portalModules']);
		});

		// Misc modules
		Route::get('filter/{module}', [GlobalSearchIndexController::class, 'filter']);
		Route::get('Activity/{id}/pre-summary', [ActivityController::class, 'preSummary']);
		Route::post('Activity/new', [ActivityController::class, 'save']);
		Route::post('Activity/{id}/activity-status-update', [ActivityController::class, 'updateStatus']);

		Route::post('comment/new', [CommentController::class, 'save']);
		Route::get('{module}/{entity_id}/comment/records', [CommentController::class, 'getEntityComments']);
		Route::get('{module}/{entity_id}/Activity/records', [ActivityController::class, 'getEntityActivities']);

		Route::post('asset/new', [AssetController::class, 'crea teAssetDoc']);
		Route::get('leads/{id}/transform', [LeadController::class, 'transformToContact']);

		// AI Search
		Route::prefix('ai-search')->group(function () {
			Route::post('query/generate', [AIQueryController::class, 'generate']);
			Route::post('query/process', [AIQueryController::class, 'processQuery']);
			Route::get('query/search', [AIQueryController::class, 'searchQuery']);
			Route::get('query/quick-access', [AIQueryController::class, 'getQuickAccessQueries']);
			Route::post('query/available-fields', [AIQueryController::class, 'getAvailableFields']);
			Route::post('query/re-execute', [AIQueryController::class, 'reExecuteQuery']);
			Route::post('query/execute-with-fields', [AIQueryController::class, 'executeWithSelectedFields']);
			Route::post('query/alter', [AIAlterQueryController::class, 'processQuery']);
		});

		// Activity routes
		Route::prefix('Activity')->group(function () {
			Route::get('my-list', [ActivityController::class, 'myActivities']);
			Route::get('{uuid}', [ActivityController::class, 'getActivityDetails'])
				->where('uuid', '[0-9a-fA-F\-]{36}');
		});

		// Filters
		Route::prefix('filters')->group(function () {
			Route::get('config', [FilterController::class, 'getConfig']);
			Route::get('/', [FilterController::class, 'index']);
			Route::post('new', [FilterController::class, 'store']);
			Route::get('{id}', [FilterController::class, 'show']);
			Route::put('{id}', [FilterController::class, 'update']);
			Route::delete('{id}', [FilterController::class, 'destroy']);
			Route::post('{id}/set-default', [FilterController::class, 'setDefault']);
			Route::post('{id}/duplicate', [FilterController::class, 'duplicate']);
			Route::get('{id}/records', [FilterController::class, 'getRecords']);
		});

		// Generic module CRUD
		Route::prefix('{module}')->group(function () {
			Route::get('/', [RecordController::class, 'index']);
			Route::post('{id}', [RecordController::class, 'store']);
			Route::get('headers', [RecordController::class, 'headerfields']);
			Route::get('new/forms', [RecordController::class, 'createForm']);
			Route::patch('{id}/inline-edit', [RecordController::class, 'inlineEdit']);
			Route::get('{id}', [RecordController::class, 'show']);
			Route::put('{id}', [RecordController::class, 'update']);
			Route::delete('{id}', [RecordController::class, 'destroy']);
			Route::get('{id}/edit', [RecordController::class, 'edit']);
			Route::get('{id}/audit-log', [RecordController::class, 'getAuditLogs']);
			Route::get('{id}/{relatedmodule}/records', [RelatedRecords::class, 'index']);
		});

	});
});
