<?php

namespace App\Modules\Api\V1\WhatsApp\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Services\WhatsApp\WhatsAppApiService;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppChannel;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppTemplateFieldMapping;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppMessage;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppInteractive;
use App\Http\Controllers\ApiController;
use App\Services\CRM\RecordObject;
use App\Traits\ResultTrait;
use Illuminate\Support\Str;
use Carbon\Carbon;


class MessageController extends Controller{
	use ResultTrait;

	public function send(Request $request, string $module, string $recordId)
	{
		$values = $request->input('data.values', []);
		$orgId  = auth()->user()->organization_id;
		/** Basic validation */
		if (
			empty($values['recipients']) ||
			empty($values['channelId']) ||
			empty($values['type'])
		) {
			return $this->error('recipients, channelId and type are required');
		}

		/** Load CRM record */
		try {
			$record = RecordObject::make($module, $recordId);
		} catch (\Throwable $e) {
			return $this->error($e->getMessage());
		}

		if (!$record) {
			return $this->error('Record not found');
		}

		/** Init service */
		$service = new WhatsAppApiService($orgId, $values['channelId']);
		if ($service->noService) {
			return $this->error('Invalid or inactive WhatsApp channel');
		}

		/** Validate WhatsApp account */
		$check = $service->validateAccount();
		if ($check['success'] === false) {
			return $this->error($check['message']);
		}

		$results = [];

		foreach ($values['recipients'] as $fieldName) {
			$to = $record->{$fieldName} ?? null;

			if (!$to) {
				$results[] = [
					'field' => $fieldName,
					'success' => false,
					'error' => 'Recipient not found'
				];
				continue;
			}

			/** Route by message type */
			switch ($values['type']) {

				/** 1️⃣ TEXT MESSAGE */
			case 'message':
				$response = $service->sendTextMessage(
					$to,
					$values['details']['text'],
					$this->buildLog($orgId, $values, $module, $fieldName, $to, 'text', $recordId,['message'=>$values['details']['text']])
				);
				break;

				/** 2️⃣ TEMPLATE MESSAGE */
			case 'template':
				$templateId = $values['details']['templateId'] ?? null;

				if (!$templateId) {
					$results[] = ['success' => false, 'error' => 'templateId missing'];
					continue 2;
				}

				$check = $service->validateTemplateMappings(
					$orgId,
					$templateId,
					$module
				);

				if ($check['success'] === false) {
					$results[] = [
						'success' => false,
						'error' => $check['message'],
						'missing_variables' => $check['missing_variables'] ?? []
					];
					continue 2;
				}

				$build = $service->buildTemplateComponents(
					$orgId,
					$templateId,
					$module,
					$record
				);

				if ($build['status'] === false) {
					$results[] = ['success' => false, 'error' => $build['message']];
					continue 2;
				}

				$response = $service->sendTemplateMessage(
					$to,
					$build['template_name'],
					'en_US',
					$build['components'],
					$this->buildLog($orgId, $values, $module, $fieldName, $to, 'template', $recordId, [
						'components' => $build['components']
					])
				);
				break;

				/** 3️⃣ INTERACTIVE MESSAGE */
			case 'interactive':
				$name = $values['details']['name'] ?? null;

				$interactive = WhatsAppInteractive::with('items')
					->where('organization_id', $orgId)
					->where('whatsapp_channel_id', $values['channelId'])
					->where('name', $name)
					->where('is_active', 1)
					->first();

				if (!$interactive) {
					$results[] = ['success' => false, 'error' => 'Interactive not found'];
					continue 2;
				}

				$payload  = $service->buildInteractivePayload($interactive, $interactive->items);
				$log      = $service->createMessageLog(
					$this->buildLog($orgId, $values, $module, $fieldName, $to, 'interactive', $recordId,['message'=>$payload['interactive']['body']['text']])
				);

				$response = $service->sendRawMessage($to, $payload);
				$service->updateMessageLog($log, $response);
				break;

				/** 4️⃣ MEDIA MESSAGE */
			case 'media':

				$details = $values['details'] ?? [];

				if (empty($details['media_type'])) {
					$results[] = ['success' => false, 'error' => 'media_type is required'];
					continue 2;
				}

				/**
				 * 1️⃣ If media_id already exists (reuse uploaded media)
				 */
				if (!empty($details['media_id'])) {

					$response = $service->sendMedia_Message(
						$to,
						$details['media_type'],
						$details['media_record_id'] ?? null,
						$details['media_id'],
						$details['caption'] ?? null,
						$this->buildLog($orgId, $values, $module, $fieldName, $to, 'media', $recordId)
					);

					break;
				}

				/**
				 * 2️⃣ Upload media first (file upload flow)
				 */
				if (!$request->hasFile('file')) {
					$results[] = [
						'success' => false,
						'error'   => 'file or media_id required'
					];
					continue 2;
				}

				// Upload once
				$upload = $service->uploadMediaToWhatsApp(
					$request->file('file'),
					$values['channelId']
				);

				if (($upload['success'] ?? false) !== true) {
					$results[] = [
						'success' => false,
						'error'   => $upload['message'] ?? 'Media upload failed'
					];
					continue 2;
				}

				$mediaId     = $upload['media_id']; // WhatsApp media id
				$mediaRowId = $upload['id'];       // DB media log id

				// Send media
				$response = $service->sendMedia_Message(
					$to,
					$details['media_type'],
					$mediaRowId,
					$mediaId,
					$details['caption'] ?? null,
					array_merge(
						$this->buildLog($orgId, $values, $module, $fieldName, $to, 'media', $recordId),
						['media_id' => $mediaRowId]
					)
				);

				break;
			default:

				$results[] = ['success' => false, 'error' => 'Invalid message type'];
				continue 2;
			}

			$results[] = [
				'field'    => $fieldName,
				'to'       => $to,
				'success'  => $response['success'] ?? false,
				'response' => $response['response'] ?? null,
				'error'    => $response['success'] ? null : ($response['message'] ?? 'Failed')
			];
		}

		return $this->success(['values' => $results], 'WhatsApp messages processed');
	}

	private function buildLog(
		string $orgId,
		array $values,
		string $module,
		string $field,
		string $to,
		string $type,
		string $recordId,
		array $extra = []
	): array {
		return array_merge([
			'organization_id'     => $orgId,
			'whatsapp_channel_id' => $values['channelId'],
			'type'                => $type,
			'crm_module'          => $module,
			'crm_field'           => $field,
			'crm_field_value'     => $to,
			'related_module'      => $module,
			'related_id'          => $recordId,
			'direction'           => 'outgoing',
		], $extra);
	}	
	public function sendWhatsAppMessage(Request $request,string $module,string $recordId) {
		$values = $request->input('data.values');		
		$orgId = auth()->user()->organization_id;
		try {
			$record = RecordObject::make($module, $recordId);
		} catch (\Throwable $e) {
			return $this->error($e->getMessage());
		}
		if (!$record) {
			return $this->error('Record not found');
		}
		foreach ($values['recipients'] as $fieldName) {
			$to = $record->{$fieldName} ?? null;
			if (!$to) {
				$results[] = [
					'recipient_field' => $fieldName,
					'to' => null,
					'success' => false,
					'error' => 'Recipient not found'
				];
				continue;
			}
			$service = new WhatsAppApiService($orgId, $values['channelId']);		
			if (!empty($service->noService)) {
				$results[] = [
					'recipient_field' => $fieldName,
					'to' => null,
					'success' => false,
					'error' => 'Invalid or inactive WhatsApp channel'
				];
				continue;
			}
			if (!empty($values['template'])) {
				$check = $service->validateTemplateMappings($orgId,$values['template'],$module);
				if ($check['success'] === false) {
					$results[] = [
						'recipient_field' => $fieldName,
						'to' => $to,
						'success' => false,
						'error' => $check['message'],
						'missing_variables' => $check['missing_variables'] ?? []
					];
					continue;
				}

				$build = $service->buildTemplateComponents($orgId,$values['template'],$module,$record);

				if ($build['status'] === false) {
					$results[] = [
						'recipient_field' => $fieldName,
						'to' => $to,
						'success' => false,
						'error' => $build['message']
					];
					continue;
				}

				$response = $service->sendTemplateMessage(
					$to,
					$values['template'],
					'en_US',
					$build['components'],
					[
						'organization_id' => $orgId,
						'whatsapp_channel_id' => $values['channelId'],
						'type' => 'template',
						'name'=> $values['template'],
						'crm_module' => $module,
						'crm_field'=>$fieldName,
						'components'=>$build['components'],
						'crm_field_value'=>$to,
						'related_module' => $module,
						'related_id' => $recordId,
					]
				);
			} else {
				$response = $service->sendTextMessage(
					$to,
					$values['message'],
					[
						'organization_id' => $orgId,
						'whatsapp_channel_id' => $values['channelId'],
						'type' => 'text',
						'message' => $values['message'],
						'crm_module' => $module,
						'crm_field' => $fieldName,
						'crm_field_value' => $to,
						'related_module' => $module,
						'related_id' => $recordId,
					]
				);

			}
			$results[] = [
				'recipient_field' => $fieldName,
				'to' => $to,
				'success' => $response['success'] ?? false,
				'response' => $response['success'] ? $response['response'] : null,
				'error' => $response['success'] ? null : ($response['message'] ?? 'Message failed')
			];
		}
		return $this->success([
			'values' => $results
		], 'Messages processed');
	}
	public function uploadMedia(Request $request)
	{
		$request->validate([
			'file' => 'required|file|max:10240',
		]);

		$orgId = auth()->user()->organization_id;

		$file  = $request->file('file');

		$localPath = $file->store('whatsapp_media');

		$service = new WhatsAppApiService($orgId);

		$response = $service->uploadMediaToWhatsApp($file);

		if (($response['success'] ?? false) !== true) {
			return $this->error(
				$response['error'] ?? 'Media upload failed'
			);
		}

		$mediaId = $response['response']['id'] ?? null;

		if (!$mediaId) {
			return $this->error('WhatsApp media id not returned');
		}

		$media	= $service->createMediaLog($orgId,$mediaId,$file);

		return $this->success([
			'media_id' => $media->media_id,
			'media_record_id' => $media->id,
		], 'Media uploaded successfully');
	}
	public function sendMediaMessage(Request $request, string $module, string $recordId)	
	{
		$orgId = auth()->user()->organization_id;
		try {
			$record = RecordObject::make($module, $recordId);
		} catch (\Throwable $e) {
			return $this->error($e->getMessage());
		}

		if (!$record) {
			return $this->error('Record not found');
		}

		$service = new WhatsAppApiService($orgId, $request->channelId);

		if (!empty($service->noService)) {
			return $this->error('Invalid or inactive WhatsApp channel');
		}

		/** 1️⃣ Upload media once */
		$upload = $service->uploadMediaToWhatsApp(
			$request->file('file'),
			$request->channelId
		);

		if ($upload['success'] === false) {
			return $this->error($upload['message']);
		}

		$mediaId   = $upload['media_id'];
		$mediaRowId = $upload['id'];

		/** 2️⃣ Send media to multiple recipients */
		$results = [];

		foreach ($request->recipients as $fieldName) {
			$to = $record->{$fieldName} ?? null;

			if (!$to) {
				$results[] = [
					'field'   => $fieldName,
					'status'  => false,
					'message' => 'Recipient not found',
				];
				continue;
			}

			$response = $service->sendMedia_Message(
				$to,
				$request->type,
				$mediaRowId,
				$mediaId,
				$request->caption,
				[
					'organization_id'      => $orgId,
					'whatsapp_channel_id'  => $request->channelId,
					'type'                 => 'media',
					'crm_module'           => $module,
					'crm_field'            => $fieldName,
					'crm_field_value'      => $to,
					'related_module'       => $module,
					'related_id'           => $recordId,
					'media_id'             => $mediaRowId,
				]
			);

			$results[] = [
				'field'    => $fieldName,
				'to'       => $to,
				'status'   => $response['success'] ?? false,
				'response' => $response['response'] ?? null,
			];
		}

		return $this->success([
			'media_id'  => $mediaRowId,
			'results'   => $results,
		], 'Media message processed');
	}
	public function validateMessage(Request $request)
	{
		return response()->json([
			'valid' => true,
			'reason' => null
		]);
	}

	public function fetchAllChats(string $module, string $recordId)
{
    $orgId = auth()->user()->organization_id;

    try {
        $record = RecordObject::make($module, $recordId);
    } catch (\Throwable $e) {
        return $this->error($e->getMessage());
    }

    if (!$record) {
        return $this->error('Record not found');
    }

    $messages = WhatsAppMessage::where('organization_id', $orgId)
         ->where('related_module', $module)
        ->where('related_id', $recordId)   // 🔑 group by record
        ->where('deleted', 0)
        ->orderBy('created_at', 'asc')
        ->get()
        ->map(function ($msg) {
            return [
                'id'          => $msg->id,
                'direction'   => $msg->direction,        // incoming / outgoing
                'type'        => $msg->type,             // text / template / media / interactive
                'message'     => $msg->message,
                'media_id'    => $msg->media_id,
                'crm_field'   => $msg->crm_field,        // phone_number / office_number
                'phone'       => $msg->crm_field_value,  // actual number
                'status'      => $msg->status,
                'created_at'  => $msg->created_at->toDateTimeString(),
            ];
        });

    return $this->success([
        'module'    => $module,
        'record_id' => $recordId,
        'messages'  => $messages,
    ]);
}
	public function fetchChats(Request $request, string $module = null, string $recordId = null)
	{
		$orgId = auth()->user()->organization_id;

		$query = WhatsAppMessage::where('organization_id', $orgId)
			->select(
				'related_module',
				'related_id',
				'crm_field',
				'crm_field_value',
				DB::raw('MAX(created_at) as last_message_time')
				//DB::raw('COUNT(CASE WHEN status = "received" AND (info NOT LIKE "%read%" OR info IS NULL) THEN 1 END) as unread_count')
			);

		if ($module && $recordId) {
			$query->where('related_module', $module)
				->where('related_id', $recordId);
		}

		// Group by unique conversation thread identifiers
		$query->groupBy('related_module', 'related_id', 'crm_field_value', 'crm_field');
		$query->orderByDesc('last_message_time');

		$threads = $query->get();

		// Fetch latest message content for each thread
		$results = $threads->map(function ($thread) {
			
			$latest = WhatsAppMessage::where('related_module', $thread->related_module)
				->where('related_id', $thread->related_id)
				->where('crm_field_value', $thread->crm_field_value)
				->latest()
				->first();

			return [
				'thread_id'       => md5($thread->related_module . $thread->related_id . $thread->crm_field_value),
				'related_module'  => $thread->related_module,
				'related_id'      => $thread->related_id,
				'phone_number'    => $thread->crm_field_value,
				'field_name'      => $thread->crm_field,
				'last_message'    => $latest ? Str::limit($latest->message, 50) : '',
				'last_time'       => $thread->last_message_time, // already carbon instance or string
				'time_ago'        => Carbon::parse($thread->last_message_time)->diffForHumans(),
				'unread_count'    => $thread->unread_count,
				'direction'       => $latest ? $latest->direction : null,
			];
		});

		return $this->success([
			'chats' => $results
		], 'Chats retrieved successfully');
	}
}
