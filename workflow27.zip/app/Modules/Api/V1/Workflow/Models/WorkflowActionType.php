<?php

namespace App\Modules\Api\V1\Workflow\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class WorkflowActionType extends Model
{
    use HasFactory, HasUuids;

    protected $table = 'workflow_action_types';

    protected $fillable = [
        'organization_id',
        'action_label',
        'status',
        'action_type',
        'function_path',
        'function_class',
        'description',
    ];

    public function modules()
    {
        return $this->belongsToMany(\App\Models\PortalModule::class, 'workflow_actiontype_module_rel', 'action_type_id', 'module_id');
    }
}
