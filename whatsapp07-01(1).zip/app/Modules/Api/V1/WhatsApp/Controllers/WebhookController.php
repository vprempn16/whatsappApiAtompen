<?php

namespace App\Modules\Api\V1\WhatsApp\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppConversation;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppChannel;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppMessage;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppTemplateFieldMapping;
use App\Services\WhatsApp\WhatsAppApiService;
use App\Traits\ResultTrait;
use Illuminate\Support\Str;
use Carbon\Carbon;

class WebhookController extends Controller{
	use ResultTrait;
	public function verify(Request $request)
	{
		$verifyToken = config('services.whatsapp.verify_token');

		if ($request->get('hub_verify_token')  && $request->get('hub_verify_token') ===  $verifyToken ) {
			return response($request->get('hub_challenge'), 200);
		}

		return $this->error('Invalid verify token', 403);
	}


	public function incomingMessage(Request $request)
	{
		$payload = $request->all();

		if (empty($payload['entry'][0]['changes'][0]['value'])) {
			return response()->json(['status' => true], 200);
		}

		$value = $payload['entry'][0]['changes'][0]['value'];

		// No messages = status-only webhook
		if (empty($value['messages'])) {
			return response()->json(['status' => true], 200);
		}

		$metadata = $value['metadata'] ?? [];
		$phoneNumberId = $metadata['phone_number_id'] ?? null;

		if (!$phoneNumberId) {
			return response()->json(['status' => true], 200);
		}

		$channel = WhatsAppChannel::where('phone_number_id', $phoneNumberId)
			->where('is_active', 1)
			->first();

		if (!$channel) {
			return response()->json(['status' => true], 200);
		}

		$orgId = $channel->organization_id;

		foreach ($value['messages'] as $msg) {

			$from = $msg['from'] ?? null;
			$type = $msg['type'] ?? 'text';

			// Default message content
			$content = null;
			$mediaId = null;

			if ($type === 'text') {
				$content = $msg['text']['body'] ?? null;
			}

			if (in_array($type, ['image', 'video', 'audio', 'document'])) {
				$mediaId = $msg[$type]['id'] ?? null;
				$content = $type;
			}

			// Save incoming message
			WhatsAppMessage::create([
				'id'              => (string) Str::uuid(),
				'organization_id' => $orgId,
				'direction'       => 'incoming',
				'type'            => $type,
				'message'         => $content,
				'media_id'        => $mediaId,
				'status'          => 'received',
				'info'            => json_encode($msg, JSON_UNESCAPED_UNICODE),
				'created_at'      => now(),
				'updated_at'      => now(),
			]);
		}

		// IMPORTANT: WhatsApp expects 200 fast
		return response()->json(['status' => true], 200);
	}

	public function messageStatus(Request $request)
	{
		return response()->json(['status_updated' => true]);
	}

	public function optOut(Request $request)
	{
		return response()->json(['opted_out' => true]);
	}
    //
}
