<?php

namespace App\Modules\Api\V1\WhatsApp\Controllers;

use App\Modules\Api\V1\WhatsApp\Models\WhatsAppTemplateFieldMapping;
use App\Http\Controllers\Controller;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Models\FieldModelManager;
use App\Http\Controllers\ApiController;
use App\Traits\ResultTrait;
use App\Services\CRM\RecordObject;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppTemplate;
use App\Services\WhatsApp\WhatsAppApiService;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppChannel;


class TemplateController extends Controller{
	use ResultTrait;

	public function listCheck(){
		$orgId = auth()->user()->organization_id;

		if (!$orgId) {
			return $this->error('Organization not found');
		}

		$exists = WhatsAppTemplate::where('organization_id', $orgId)->exists();

		return $this->success([
			'has_templates' => $exists
		]);

	}

	public function syncTemplates()
	{
		$orgId = auth()->user()->organization_id;

		$service = new WhatsAppApiService($orgId);

		$validate = $service->validateAccount();	
		
		if($validate['success'] === false){
			return $this->error($validate['message']);
		}
		
		$result = $service->fetchAndSyncTemplates($orgId);

		if($result['success'] === false){
			return $this->error($result['message']);
		}
		return $this->success($result['message']);
	}
	public function getWhatsAppTemplates(Request $request)
	{
		$data = $request->input('data.values', []);	

		$orgId = auth()->user()->organization_id;
		if ($orgId == '') {
			return $this->error('organization_id required');
		}

		$service = new WhatsAppApiService($orgId);

		if($service->noSerivce){
			 return $this->error('This Organization has no service');
		}
		
		$validate = $service->validateAccount();

                if($validate['success'] === false){
                        return $this->error($validate['message']);
		}

		$response = $service->getTemplates();

		return response()->json([
			'data' => [
				'values' => $response['response']['data'] ?? []
			]
		]);
	}
	public function getMappingTemplates(Request $request){

		$organizationId = $request->get('organization_id');

		$templates = WhatsAppTemplateFieldMapping::where(
			'organization_id',
			$organizationId
		)->get();

		$values = $templates->map(function ($row) {
			return [
				'id'                => $row->id,
				'template_name'     => $row->template_name,
				'language'          => $row->template_language,
				'template_variable' => $row->template_variable,
				'crm_module'        => $row->crm_module,
				'crm_field'         => $row->crm_field,
			];
		});

		return response()->json([
			'data' => [
				'values' => $values
			]
		]);
	}
	public function getTemplateByName(Request $request){
		$values = $request->input('data.values');

		$orgId = auth()->user()->organization_id;
		
		$request->validate([
			'data.values.template_name'   => 'required|string',
		]);
		$service = new WhatsAppApiService($orgId);

                if($service->noSerivce){
                         return $this->error('This Organization has no service');
                }
		$result = $service->getTemplateByName(
			$values['template_name']
		);
		return response()->json([
			'data' => [
				'values' => $result['response']['data'] ?? []
			]
		]);
	}

	public function getTemplateMapping(Request $request,string $id = null){
		$orgId = auth()->user()->organization_id;
		$mapping = WhatsAppTemplateFieldMapping::where(
			'id', $id
		)->where(
			'organization_id', $values['organization_id']
		)->get();

		return response()->json([
			'data' => [
				'values' => $mapping
			]
		]);
	}
	public function getMappingTemplateByName(
		Request $request,
		string $templateName,
		string $module
	) {
		$orgId = auth()->user()->organization_id;

		$mapping = WhatsAppTemplateFieldMapping::where('organization_id', $orgId)
			->where('template_name', $templateName)
			->where('module', $module) // ✅ NEW condition
			->get();

		return response()->json([
			'data' => [
				'values' => $mapping
			]
		]);
	}
	public function save(Request $request, string $templateName = null){
		$data = $request->input('data.values', []);
		$orgId = auth()->user()->organization_id;

		if (empty($orgId) || empty($data['template_name'])) {
			return $this->error('organization_id and template_name are required');
		}
		
		if (empty($data['mappings']) || !is_array($data['mappings'])) {
			return $this->error('Mappings are required');
		}
		// Validate CRM module & fields before saving
		foreach ($data['mappings'] as $map) {
			if (empty($map['crm_module']) || empty($map['crm_field']) || empty($map['template_variable']) ) {
				return $this->error('Invalid mapping data');
			}
			//  CRM FIELD VALIDATION (your existing CRM way)
			try {
				$fieldManager = FieldModelManager::make(
					$map['crm_module'],
					'DetailView'
				);

				$fields = $fieldManager->getFields();

				if (!isset($fields[$map['crm_field']])) {
					return $this->error("Field {$map['crm_field']} not found in module {$map['crm_module']}");
				}
			} catch (\Throwable $e) {
					return $this->error("Invalid CRM module: {$map['crm_module']}");
			}
		}
		foreach ($data['mappings'] as $mapping) {
			if ($templateName) {
				// UPDATE by template_name + variable
				$record = WhatsAppTemplateFieldMapping::where(
					'organization_id', $orgId
				)->where(
					'template_name', $templateName
				)->where(
					'template_variable', $mapping['template_variable']
				)->first();
				if ($record) {
					$record->update([
						'module'         => $data['module'],
						'crm_module'     => $mapping['crm_module'],
						'crm_field'      => $mapping['crm_field'],
						'component_type' => strtoupper($mapping['component_type'] ?? 'BODY'),
						'button_index'   => $mapping['component_index'] ?? null,
					]);
				}

			}else {
				//  CREATE case
				WhatsAppTemplateFieldMapping::create([
					'id'                => (string) Str::uuid(),
					'organization_id'   => $orgId,
					'module'            => $data['module'],
					'template_name'     => $data['template_name'],
					'template_language' => $data['language'],
					'template_variable' => $mapping['template_variable'],
					'component_type'    => strtoupper($mapping['component_type'] ?? 'BODY'),
					'button_index'      => $mapping['component_index'] ?? null,
					'crm_module'        => $mapping['crm_module'],
					'crm_field'         => $mapping['crm_field'],
				]);
			}
		}
		return $this->success(
			$templateName
			? 'Template mapping updated successfully'
			: 'Template mapping created successfully'
		);
	}
	public function previewTemplate(Request $request,string $templateName,string $module,string $recordId) {
		$orgId = auth()->user()->organization_id;

		$template = WhatsAppTemplate::where('organization_id', $orgId)
			->where('template_name', $templateName)
			->first();

		if (!$template) {
			return $this->error('Template not found');
		}
		$service = new WhatsAppApiService($orgId);
		$check = $service->validateTemplateMappings($orgId,$templateName,$module);

		if ($check['success'] === false) {
			return $this->error([
				'message' => $check['message'],
				'missing_variables' => $check['missing_variables'] ?? []
			]);
		}


		$record = RecordObject::make($module, $recordId);
		if (!$record) {
			return $this->error('CRM record not found');
		}

		$mappings = WhatsAppTemplateFieldMapping::where('organization_id', $orgId)
			->where('template_name', $templateName)
			->where('module', $module)
			->get();

		$fieldManager = FieldModelManager::make($module, 'DetailView');
		$valueMap = [];

		foreach ($mappings as $map) {
			$fieldModel = $fieldManager->getFieldModel($map->crm_field);
			if (!$fieldModel) {
				continue;
			}

			$fieldName = $fieldModel->getFieldName();
			$valueMap[$map->template_variable] = (string) ($record->{$fieldName} ?? '');
		}

		$preview = [];

		foreach ($template->components as $component) {

			/* HEADER */
			if ($component['type'] === 'HEADER' && ($component['format'] ?? '') === 'TEXT') {
				$preview[] = [
					'type' => 'header',
					'text' => $this->replaceVars($component['text'], $valueMap)
				];
			}

			/* BODY */
			if ($component['type'] === 'BODY') {
				$preview[] = [
					'type' => 'body',
					'text' => $this->replaceVars($component['text'], $valueMap)
				];
			}

			/* BUTTONS */
			if ($component['type'] === 'BUTTONS') {
				foreach ($component['buttons'] as $index => $btn) {

					$button = [
						'type'  => 'button',
						'index' => $index,
						'text'  => $btn['text'],
						'button_type' => $btn['type'] // URL / PHONE_NUMBER / QUICK_REPLY
					];

					if ($btn['type'] === 'URL' && !empty($btn['url'])) {
						$button['url'] = $this->replaceVars($btn['url'], $valueMap);
					}

					if ($btn['type'] === 'PHONE_NUMBER' && !empty($btn['phone_number'])) {
						$button['phone_number'] = $btn['phone_number'];
					}

					$preview[] = $button;
				}
			}
		}
		return $this->success([
			'template' => $templateName,
			'module'   => $module,
			'recordId'=> $recordId,
			'preview'  => $preview
		]);
	}
	private function replaceVars(string $text, array $values): string
	{
		foreach ($values as $key => $val) {
			// Named {{name}}
			$text = str_replace('{{'.$key.'}}', $val, $text);

			// Positional {{1}}
			if (is_numeric($key)) {
				$text = str_replace('{{'.$key.'}}', $val, $text);
			}
		}
		return $text;
	}
}
