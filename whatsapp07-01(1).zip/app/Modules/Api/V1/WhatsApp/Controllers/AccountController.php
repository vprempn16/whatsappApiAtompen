<?php


namespace App\Modules\Api\V1\WhatsApp\Controllers;

use App\Modules\Api\V1\WhatsApp\Models\WhatsAppChannel;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\ApiController;
use App\Services\WhatsApp\WhatsAppApiService;
use App\Traits\ResultTrait;
use Illuminate\Support\Str;
use Carbon\Carbon;

class AccountController extends Controller
{
	use ResultTrait;
	public function accountsInfo()
	{
		return response()->json([
			'business_name'   => 'Demo Business',
			'whatsapp_number' => '+91XXXXXXXXXX',
			'waba_status'     => 'APPROVED'
		]);
	}
	public function getByOrg(){
		$orgId = auth()->user()->organization_id;

		$account = WhatsAppChannel::where('organization_id', $orgId) 
			->where('is_active', true)
			->first();
		if (!$account) {
			return $this->error('WhatsApp account not configured');
		}

		return $this->success([
			'app_id'          => $account->app_id,
			'phone_number_id' => $account->phone_number_id,
			'business_id'     => $account->business_id,
		]);
	}

	public function save(Request $request)
	{
		$data = $request->input('data.values', []);
		$orgId = auth()->user()->organization_id;
		// Basic validation
		foreach (['app_id','app_secret','phone_number_id','business_id','access_token'] as $field) {
			if (empty($data[$field])) {
				return $this->error("$field is required");
			}
		}

		$service = new WhatsAppApiService($orgId);

		$check = $service->validateAccount($data);
		if ($check['success'] === false) {
			return $this->error($check['message']);
		}

		// Save or update per organization
		WhatsAppChannel::updateOrCreate(
			['organization_id' => $orgId],
			[
				'id' => (string) Str::uuid(),
				'name'            => $data['name'],
				'desc'            => $data['desc'] ?? null,
				'app_id'          => $data['app_id'],
				'app_secret'      => $data['app_secret'],
				'phone_number_id' => $data['phone_number_id'],
				'business_id'     => $data['business_id'],
				'access_token'    => $data['access_token'],
				'is_active'       => true,
				'created_by'      => auth()->id(),
				'updated_at'      => now(),
			]
		);
		return $this->success(null, 'WhatsApp account connected successfully');
	}
	public function healthCheck()
	{
		$orgId = auth()->user()->organization_id;
		$exists = WhatsAppChannel::where('organization_id', $orgId) 
			  ->where('is_active', true)
			->exists();
		return response()->json([
			'data' => [
				'values' => [
					'connected' => $exists
				]
			]
		]);
	}

}
