<?php

namespace App\Modules\Api\V1\WhatsApp\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Services\WhatsApp\WhatsAppApiService;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppChannel;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppTemplateFieldMapping;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppMessage;
use App\Http\Controllers\ApiController;
use App\Services\CRM\RecordObject;
use App\Traits\ResultTrait;
use Illuminate\Support\Str;
use Carbon\Carbon;


class MessageController extends Controller{
	        use ResultTrait;
	public function sendTextMessage(Request $request){
		$request->validate([
			'organization_id' => 'required|string',
			'to'              => 'required|string',
			'message'         => 'required|string',
		]);

		$config = WhatsAppChannel::where(
			'organization_id',
			$request->organization_id
		)->first();

		if (!$config) {
			return response()->json([
				'status'  => false,
				'message' => 'WhatsApp config not found'
			], 404);
		}

		// ✅ Use Service class
		$whatsAppService = new WhatsAppApiService(
			$config->access_token,
			$config->phone_number_id
		);

		$result = $whatsAppService->sendTextMessage(
			$request->to,
			$request->message
		);

		return response()->json($result);
	}

	public function sendTemplate(Request $request)
	{
		$request->validate([
			'organization_id' => 'required|string',
			'to'              => 'required|string',
			'template_name'   => 'required|string',
			'language'        => 'required|string',
			'components'      => 'nullable|array',
		]);

		$config = WhatsAppChannel::where(
			'organization_id',
			$request->organization_id
		)->first();

		if (!$config) {
			return response()->json([
				'status'  => false,
				'message' => 'WhatsApp configuration not found'
			], 404);
		}

		$whatsAppService = new WhatsAppApiService($config->access_token,$config->phone_number_id);

		$result = $whatsAppService->sendTemplateMessage($request->to,$request->template_name,$request->language,$request->components ?? [] );

		return response()->json($result);
	}	
	public function sendWhatsAppMessage(Request $request,string $module,string $recordId) {
		$values = $request->input('data.values');
		
		$orgId = auth()->user()->organization_id;

		try {
			$record = RecordObject::make($module, $recordId);
		} catch (\Throwable $e) {
			return $this->error($e->getMessage());
		}
		
		if (!$record) {
			return $this->error('Record not found');
		}

		foreach ($values['recipients'] as $fieldName) {
			$to = $record->{$fieldName} ?? null;
			if (!$to) {
				$results[] = [
					'recipient_field' => $fieldName,
					'to' => null,
					'success' => false,
					'error' => 'Recipient not found'
				];
				continue;
			}
			$service = new WhatsAppApiService($orgId, $values['channelId']);
				
			if (!empty($service->noService)) {
				$results[] = [
                                        'recipient_field' => $fieldName,
                                        'to' => null,
                                        'success' => false,
                                        'error' => 'Invalid or inactive WhatsApp channel'
                                ];
                                continue;
			}
			if (!empty($values['template'])) {
				$check = $service->validateTemplateMappings($orgId,$values['template'],$module);
				if ($check['success'] === false) {
					$results[] = [
						'recipient_field' => $fieldName,
						'to' => $to,
						'success' => false,
						'error' => $check['message'],
						'missing_variables' => $check['missing_variables'] ?? []
					];
					continue;
				}

				$build = $service->buildTemplateComponents($orgId,$values['template'],$module,$record);

				if ($build['status'] === false) {
					$results[] = [
						'recipient_field' => $fieldName,
						'to' => $to,
						'success' => false,
						'error' => $build['message']
					];
					continue;
				}

				$response = $service->sendTemplateMessage(
					$to,
					$values['template'],
					'en_US',
					$build['components'],
					[
						'organization_id' => $orgId,
						'whatsapp_channel_id' => $values['channelId'],
						'type' => 'template',
						'name'=> $values['template'],
						'crm_module' => $module,
						'crm_field'=>$fieldName,
						'components'=>$build['components'],
						'crm_field_value'=>$to,
					]
				);
			} else {
				$response = $service->sendTextMessage(
					$to,
					$values['message'],
					[
						'organization_id' => $orgId,
						'whatsapp_channel_id' => $values['channelId'],
						'type' => 'text',
						'message' => $values['message'],
						'crm_module' => $module,
						'crm_field' =>$values['recipent'],
						'crm_field_value'=>$to,
					]
				);
			}
			$results[] = [
				'recipient_field' => $fieldName,
				'to' => $to,
				'success' => $response['success'] ?? false,
				'response' => $response['success'] ? $response['response'] : null,
				'error' => $response['success'] ? null : ($response['message'] ?? 'Message failed')
			];
		}
		return $this->success([
			'values' => $results
		], 'Messages processed');
	}
	public function uploadMedia(Request $request)
	{
		$request->validate([
			'file' => 'required|file|max:10240',
		]);

		$orgId = auth()->user()->organization_id;

		$file  = $request->file('file');

		$localPath = $file->store('whatsapp_media');

		$service = new WhatsAppApiService($orgId);

		$response = $service->uploadMediaToWhatsApp($file);
		
		if (($response['success'] ?? false) !== true) {
			return $this->error(
				$response['error'] ?? 'Media upload failed'
			);
		}

		$mediaId = $response['response']['id'] ?? null;

		if (!$mediaId) {
			return $this->error('WhatsApp media id not returned');
		}

		$media	= $service->createMediaLog($orgId,$mediaId,$file);

		return $this->success([
			'media_id' => $media->media_id,
			'media_record_id' => $media->id,
		], 'Media uploaded successfully');
	}
	public function sendMediaMessage(Request $request, string $module, string $recordId)
	{
		$request->validate([
			'file' => 'required|file|max:10240',
			'recipient' => 'required|string',
			'type' => 'required|string|in:image,video,document,audio',
			'caption' => 'nullable|string',
		]);

		$orgId = auth()->user()->organization_id;

		$record = RecordObject::make($module, $recordId);
		if (!$record) {
			return $this->error('Record not found');
		}

		$to = $record->{$request->recipient} ?? null;
		if (!$to) {
			return $this->error('Recipient phone not found');
		}

		$service = new WhatsAppApiService($orgId);

		$upload = $service->uploadMediaToWhatsApp($request->file('file'));

		if ($upload['success'] === false) {
			return $this->error($upload['message']);
		}

		$mediaId = $upload['media_id'];
		$id =  $upload['id'];
		$response = $service->sendMedia_Message(
			$to,
			$request->type,
			$id,
			$mediaId,
			$request->caption,
			[
				'organization_id' => $orgId,
				'type' => 'media',
				'crm_module' => $module,
				'crm_field' => $request->recipient,
				'crm_field_value' => $to,
			]
		);

		return $response['success']
			? $this->success($response['response'], 'Media message sent')
			: $this->error('Media message failed');	
	}
	public function validateMessage(Request $request)
	{
		return response()->json([
			'valid' => true,
			'reason' => null
		]);
	}


}
