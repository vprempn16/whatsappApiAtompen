<?php

namespace App\Services\WhatsApp;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppChannel;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppTemplateFieldMapping;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppMessage;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppTemplate;
use App\Modules\Api\V1\WhatsApp\Models\WhatsAppMedia;

use Illuminate\Support\Facades\Log;
use App\Services\CRM\RecordObject;
use Illuminate\Support\Str;
use Carbon\Carbon;


class WhatsAppApiService{
	protected string $accessToken;
	protected string $phoneNumberId;
	 public ?string $channelId = null;
	public bool $noSerivce = false;
	protected string $baseUrl = 'https://graph.facebook.com/v22.0';

	public function __construct(string $organizationId ,string $channelId)
	{
		$config = WhatsAppChannel::where('id', $channelId)
			->where('organization_id', $organizationId)
			->where('is_active', 1)
			->first();
			
		if(!$config){
			$this->noSerivce = true;
		}
		if($config){
			$this->channelId      = $config->id;
			$this->accessToken   = $config->access_token;
			$this->phoneNumberId = $config->phone_number_id;
			$this->businessId = $config->business_id;
			$this->organizationId = $organizationId;
		}
	}
	public function validateAccount(array $data = []): array
	{
		$url = "{$this->baseUrl}/{$this->businessId}";

		$response = self::request(
			$url,
			$this->accessToken,
			['fields' => 'id'],
			'GET'
		);

		if (($response['success'] ?? false) !== true) {
			return [
				'success' => false,
				'message' => 'Unable to connect to WhatsApp API'
			];
		}

		if (!empty($response['response']['error'])) {
			return [
				'success' => false,
				'message' => $response['response']['error']['message'] ?? 'Invalid WhatsApp credentials'
			];
		}

		// business id must match
		if(($response['response']['id'] ?? null) !== $this->businessId) {
			return [
				'success' => false,
				'message' => 'Business ID mismatch'
			];
		}
		return [
			'success' => true
		];
	}
	public static function request1(string $url,string $accessToken,array $payload = [],string $method = 'POST',array $headers = [] ): array {
		$ch = curl_init($url);
		$defaultHeaders = [
			'Authorization: Bearer ' . $accessToken,
			'Content-Type: application/json',
		];
		$options = [
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_TIMEOUT        => 30,
			CURLOPT_HTTPHEADER     => array_merge($defaultHeaders, $headers),
		];
		switch (strtoupper($method)) {
		case 'POST':
			$options[CURLOPT_POST] = true;
			$options[CURLOPT_POSTFIELDS] = json_encode($payload);
			break;

		case 'PUT':
		case 'PATCH':
			$options[CURLOPT_CUSTOMREQUEST] = $method;
			$options[CURLOPT_POSTFIELDS] = json_encode($payload);
			break;

		case 'GET':
			if (!empty($payload)) {
				$url .= '?' . http_build_query($payload);
				curl_setopt($ch, CURLOPT_URL, $url);
			}
			break;

		case 'DELETE':
			$options[CURLOPT_CUSTOMREQUEST] = 'DELETE';
			break;
		}
		curl_setopt_array($ch, $options);
		$response = curl_exec($ch);
		$error    = curl_error($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		if ($error) {
			return [
				'success' => false,
				'error'   => $error,
			];
		}
		return [
			'success'   => true,
			'response'  => json_decode($response, true),
		];
	}
	public static function request(string $url,string $accessToken,array $payload = [],string $method = 'POST',array $headers = [],bool $isMultipart = false): array {
		$ch = curl_init($url);
		$defaultHeaders = [
			'Authorization: Bearer ' . $accessToken,
		];
		if (!$isMultipart) {
			$defaultHeaders[] = 'Content-Type: application/json';
		}
		$options = [
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_TIMEOUT        => 30,
			CURLOPT_HTTPHEADER     => array_merge($defaultHeaders, $headers),
		];
		switch (strtoupper($method)) {
		case 'POST':
			$options[CURLOPT_POST] = true;
			$options[CURLOPT_POSTFIELDS] = $isMultipart ? $payload : json_encode($payload);
			break;

		case 'PUT':
		case 'PATCH':
			$options[CURLOPT_CUSTOMREQUEST] = $method;
			$options[CURLOPT_POSTFIELDS] = $isMultipart ? $payload : json_encode($payload);
			break;
		case 'GET':
			if (!empty($payload)) {
				$url .= '?' . http_build_query($payload);
				curl_setopt($ch, CURLOPT_URL, $url);
			}
			break;
		case 'DELETE':
			$options[CURLOPT_CUSTOMREQUEST] = 'DELETE';
			break;
		}
		curl_setopt_array($ch, $options);
		$response = curl_exec($ch);
		$error    = curl_error($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		if ($error) {
			return [
				'success' => false,
				'message' => $error,
			];
		}
		return [
			'httpCode' => $httpCode,
			'success'   => true,
                        'response'  => json_decode($response, true),
		];
	}
	public function buildTemplateComponents(string $organizationId,string $templateName,string $module,$record ): array {

		  $template = WhatsAppTemplate::where('organization_id', $organizationId)
        ->where('template_name', $templateName)
	->first();

		if (!$template){
			return [
				'status' => false,
				'message' => 'WhatsApp template not found',
				'components' => []
			];
		}

		$isNamed = $template && $template->format === 'NAMED';

		$mappings = WhatsAppTemplateFieldMapping::where(
			'organization_id', $organizationId
		)->where(
			'template_name', $templateName
		)->where(
			'crm_module', $module
		)->get();

		if ($mappings->isEmpty()) {
			return [
				'status' => false,
				'message' => 'Template field mappings not configured',
				'components' => []
			];
		}

		try {
			$fieldManager = \App\Models\FieldModelManager::make($module, 'EditView');
		} catch (\Throwable $e) {
			return [
				'status' => false,
				'message' => 'Invalid CRM module',
				'components' => []
			];
		}

		/** --------------------------------
		 * Build value map (template_variable => value)
		 ----------------------------------*/
		$valueMap = [];

		foreach ($mappings as $map) {
			$fieldModel = $fieldManager->getFieldModel($map->crm_field);
			if (!$fieldModel) {
				return [
					'status' => false,
					'message' => "CRM field {$map->crm_field} not found",
					'components' => []
				];
			}

			$fieldName = $fieldModel->getFieldName();
			$valueMap[$map->template_variable] = (string) ($record->{$fieldName} ?? '');
		}

		$components = [];

		/** --------------------------------
		 * Loop through template components
		 ----------------------------------*/
		foreach ($template->components as $component) {

			/* ---------- HEADER ---------- */
			if ($component['type'] === 'HEADER' && isset($component['format']) && $component['format'] === 'TEXT') {

				if (str_contains($component['text'], '{{')) {
					$components[] = [
						'type' => 'header',
						'parameters' => $this->buildParams($component, $valueMap, $isNamed)
					];
				}
			}

			/* ---------- BODY ---------- */
			if ($component['type'] === 'BODY') {
				$components[] = [
					'type' => 'body',
					'parameters' => $this->buildParams($component, $valueMap, $isNamed)
				];
			}

			/* ---------- BUTTONS ---------- */
			if ($component['type'] === 'BUTTONS') {
				foreach ($component['buttons'] as $index => $button) {

					if ($button['type'] === 'URL' && str_contains($button['url'], '{{')) {
						$components[] = [
							'type' => 'button',
							'sub_type' => 'url',
							'index' => (string) $index,
							'parameters' => $this->buildButtonParams($button, $valueMap, $isNamed)
						];
					}
				}
			}
		}
		return [
			'status' => true,
			'message' => 'Components built successfully',
			'components' => $components
		];
	}
	private function buildParams(array $component, array $valueMap, bool $isNamed): array
	{
		$params = [];

		if ($isNamed) {
			foreach ($valueMap as $name => $value) {
				$params[] = [
					'type' => 'text',
					'text' => $value,
					'parameter_name' => $name
				];
			}
		} else {
			preg_match_all('/{{\d+}}/', $component['text'], $matches);
			foreach ($matches[0] as $index => $placeholder) {
				$params[] = [
					'type' => 'text',
					'text' => array_values($valueMap)[$index] ?? ''
				];
			}
		}

		return $params;
	}
	private function buildButtonParams(array $button, array $valueMap, bool $isNamed): array
	{
		if ($isNamed) {
			return [[
				'type' => 'text',
				'text' => reset($valueMap)
			]];
		}

		// POSITIONAL ({{1}})
		return [[
			'type' => 'text',
			'text' => reset($valueMap)
		]];
	}
	public function getTemplates(): array 
	{
		$url = "{$this->baseUrl}/{$this->businessId}/message_templates";
		return self::request(
			$url,
			$this->accessToken,
			[],
			'GET'
		);
	}
	public function getTemplateByName(string $templateName): array
	{
		$url = "{$this->baseUrl}/{$this->businessId}/message_templates";

		$response = self::request(
			$url,
			$this->accessToken,
			[
				'name' => $templateName
			],
			'GET'
		);
		return $response;
	}
	public function sendTextMessage(string $to,string $message,array $logData): array {
		$log = $this->createMessageLog($logData);

		$response = self::request(
			"{$this->baseUrl}/{$this->phoneNumberId}/messages",
			$this->accessToken,
			[
				'messaging_product' => 'whatsapp',
				'to' => $to,
				'type' => 'text',
				'text' => ['body' => $message]
			]
		);

		$this->updateMessageLog($log, $response);
		return $response;
	}
	public function sendTemplateMessage(string $to,string $templateName,string $language,array $components,array $logData ): array {
		$log = $this->createMessageLog($logData);

		$response = self::request(
			"{$this->baseUrl}/{$this->phoneNumberId}/messages",
			$this->accessToken,
			[
				'messaging_product' => 'whatsapp',
				'to' => $to,
				'type' => 'template',
				'template' => [
					'name' => $templateName,
					'language' => ['code' => $language],
					'components' => $components
				]
			]
		);

		$this->updateMessageLog($log, $response);
		return $response;
	}
	public function updateMessageLog(WhatsAppMessage $message,array $response ): void {
		if ($response['success'] ?? false) {
			$message->update([
				'status'     => 'sent',
				'message_id' => $response['response']['messages'][0]['id'] ?? null,
				'info'       => json_encode([
					'status'   => 'sent',
					'response' => $response
				], JSON_UNESCAPED_UNICODE)
			]);

		} else {

			$message->update([
				'status' => 'failed',
				'info'   => json_encode([
					'status'   => 'failed',
					'error'    => $response
				], JSON_UNESCAPED_UNICODE)
			]);
		}
	}
	public function createMessageLog(array $data): WhatsAppMessage{
		return WhatsAppMessage::create([
			'id' => (string) Str::uuid(),
			'organization_id' => $data['organization_id'],
			'whatsapp_channel_id' => $data['whatsapp_channel_id'],
			'direction' => 'outgoing',
			'type' => $data['type'],
			'message' => isset($data['components'])
            ? json_encode($data['components'], JSON_UNESCAPED_UNICODE)
            : ($data['message'] ?? null),
			'crm_module' => $data['crm_module'] ?? null,
			'crm_field' => $data['crm_field'] ?? null,
			'crm_field_value' => $data['crm_field_value'] ?? null,
			'status' => 'open',
			'info' => isset($data['info']) ? json_encode($data['info'], JSON_UNESCAPED_UNICODE) : null,
			'created_by' => auth()->id(),
			'created_at' => now(),
			'updated_at' => now(),
		]);	
	}
	public function fetchAndSyncTemplates(string $organizationId): array
	{
		$config = WhatsAppChannel::where('organization_id', $organizationId)
 			->where('is_active', true)
			->first();


		$url = "{$this->baseUrl}/{$this->businessId}/message_templates";
		$response = self::request(
			$url,
			$config->access_token,
			[],
			'GET'
		);
		if (!empty($response['response']['error'] ?? null)) {
			return [
				'success' => false,
				'message' => $response['response']['error'],
			];
		}
		foreach ($response['response']['data'] ?? [] as $tpl) {
			WhatsAppTemplate::updateOrCreate(
				[
					'organization_id' => $organizationId,
					'template_name'   => $tpl['name'],
					'language'        => $tpl['language'],
				],
				[
					'id'          => (string) Str::uuid(),
					'template_id' => $tpl['id'],
					'format'      => $tpl['parameter_format'], // POSITIONAL | NAMED
					'status'      => $tpl['status'],
					'components'  => $tpl['components'] ?? [],
					'category'    => $tpl['category'] ?? null,
					'updated_at'  => now(),
				]
			);
			WhatsAppChannelTemplateRel::updateOrCreate(
				[
					'whatsapp_channels_id' => $channel->id,
					'whatsapp_template_id' => $template->id,
				],
				[
					'id' => (string) Str::uuid()
				]
			);
		}
		return [
			'success' => true,
			'message' => 'Templates synced successfully'
		];
	}
	public function createMediaLog(string $orgId,string $mediaId,$file,string $localPath) {
		return WhatsAppMedia::create([
			'id'              => (string) Str::uuid(),
			'organization_id' => $orgId,
			'media_id'        => $mediaId,
			'mime_type'       => $file->getMimeType(),
			'file_name'       => $file->getClientOriginalName(),
			'local_path'      => $localPath,
			'created_by'      => auth()->id(),
			'created_at'      => now(),
			'updated_at'      => now(),
		]);
	}
	public function uploadMediaToWhatsApp($file ): array
	{
		$url = "{$this->baseUrl}/{$this->phoneNumberId}/media";
		$config = WhatsAppChannel::where('organization_id', $this->organizationId)->first();

		$payload = [
			'messaging_product' => 'whatsapp',
			'type' => $file->getMimeType(),
			'file' => new \CURLFile(
				$file->getRealPath(),
				$file->getMimeType(),
				$file->getClientOriginalName()
			),
		];
		$response = self::request(
			$url,
			$this->accessToken,
			$payload,
			'POST',
			[],
			true // ✅ multipart
		);
		if ($response['success'] === false) {
			return $response;
		}

		if (empty($response['response']['id'])) {
			return [
				'success' => false,
				'message' => 'Media ID not returned'
			];
		}

		// Save media log
		$result = $this->createMediaLog($this->organizationId,$response['response']['id'],$file, $file->store('whatsapp_media') );
		return [
			'success' => true,
			'media_id' => $response['response']['id'],
			'id'=>$result->id,
		];
	}
	public function sendMedia_Message(string $to,string $type,string $id,string $mediaId,?string $caption,array $logData ): array {

		$log = $this->createMessageLog(array_merge($logData, [
			'message' => $caption,
		]));

		$payload = [
			'messaging_product' => 'whatsapp',
			'to' => $to,
			'type' => $type,
			$type => [
				'id' => $mediaId,
			]
		];

		if ($caption && in_array($type, ['image','video','document'])) {
			$payload[$type]['caption'] = $caption;
		}

		$response = self::request(
			 "{$this->baseUrl}/{$this->phoneNumberId}/messages",
			$this->accessToken,
			$payload
		);

		/** Update log */
		if ($response['success'] && isset($response['response']['messages'][0]['id'])) {
			$log->update([
				'status' => 'sent',
				'message_id' => $response['response']['messages'][0]['id'],
				'media_id' => $id,
				'info' => json_encode($response['response']),
			]);
		} else {
			$log->update([
				'status' => 'failed',
				'info' => json_encode($response),
			]);
		}

		return $response;
	}
	public function validateTemplateMappings(string $orgId,string $templateName,string $module): array {
		// 1️⃣ Fetch template
		$template = WhatsAppTemplate::where('organization_id', $orgId)
			->where('template_name', $templateName)
			->first();
		if (!$template) {
			return [
				'success' => false,
				'message' => 'Template not found'
			];
		}
		$components = $template->components ?? [];

		// 2️⃣ Collect required variables
		$requiredVars = [];
		foreach ($components as $component) {

			/* -------- HEADER / BODY / FOOTER -------- */
			if (!empty($component['text'])) {
				preg_match_all('/{{\s*([a-zA-Z0-9_]+)\s*}}/', $component['text'], $matches);
				foreach ($matches[1] as $var) {
					$requiredVars[] = $var;
				}
			}

			/* -------- BUTTONS (URL only) -------- */
			if (($component['type'] ?? '') === 'BUTTONS') {
				foreach ($component['buttons'] ?? [] as $btn) {
					if (($btn['type'] ?? '') === 'URL' && !empty($btn['url'])) {
						preg_match_all('/{{\s*([a-zA-Z0-9_]+)\s*}}/', $btn['url'], $matches);
						foreach ($matches[1] as $var) {
							$requiredVars[] = $var;
						}
					}
				}
			}
		}

		$requiredVars = array_unique($requiredVars);

		// 3️⃣ Fetch saved mappings
		$mappedVars = WhatsAppTemplateFieldMapping::where('organization_id', $orgId)
			->where('template_name', $templateName)
			->where('module', $module)
			->pluck('template_variable')
			->toArray();


		// 4️⃣ Find missing mappings
		$missing = array_diff($requiredVars, $mappedVars);

		if (!empty($missing)) {
			return [
				'success' => false,
				'message' => 'Template variable mapping missing',
				'missing_variables' => array_values($missing)
			];
		}

		// 5️⃣ All good
		return [
			'success' => true
		];
	}
}

