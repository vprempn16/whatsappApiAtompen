<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('whatsapp_channels', function (Blueprint $table) {
		Schema::rename('whatsapp_org_rel', 'whatsapp_channels');

		Schema::table('whatsapp_channels', function (Blueprint $table) {
			$table->string('name')->after('organization_id');
			$table->text('desc')->nullable()->after('name');
			$table->boolean('is_active')->default(true)->after('desc');
			$table->char('created_by', 36)->nullable()->after('access_token');
			$table->foreign('organization_id')->references('id')
	 ->on('organizations')
	 ->onDelete('cascade');
		});
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('whatsapp_channels', function (Blueprint $table) {
		Schema::table('whatsapp_channels', function (Blueprint $table) {
			$table->dropColumn(['name', 'desc', 'is_active', 'created_by']);
		});

		Schema::rename('whatsapp_channels', 'whatsapp_org_rel');
            //
        });
    }
};
