<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
	public function up()
	{
		Schema::table('whatsapp_org_rel', function (Blueprint $table) {
			$table->char('id', 36)->change();
		});
	}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
