<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
	    Schema::create('whatsapp_channel_template_rel', function (Blueprint $table) {
		    $table->char('id', 36)->primary();
		    $table->char('whatsapp_channels_id', 36);
		    $table->char('whatsapp_template_id', 36);
		    $table->timestamps();
	    });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('whatsapp_channel_template_rel');
    }
};
