<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
	    Schema::create('whatsapp_messages', function (Blueprint $table) {
		    $table->char('id', 36)->primary();
		    $table->char('organization_id', 36);

		    $table->string('message_id')->nullable(); // WhatsApp message id
		    $table->enum('direction', ['incoming', 'outgoing']);
		    $table->string('type', 50); // text / template / media

		    $table->text('message')->nullable();

		    $table->string('crm_module', 100)->nullable();
		    $table->string('crm_field', 100)->nullable();
		    $table->text('crm_field_value')->nullable();

		    $table->string('status', 50)->default('open'); // open, sent, failed
		    $table->string('media_id')->nullable();

		    $table->char('created_by', 36)->nullable();
		    $table->tinyInteger('deleted')->default(0);

		    $table->timestamp('created_at')->nullable();
		    $table->timestamp('updated_at')->nullable();

		    $table->index('organization_id');
	    });

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('whatsapp_messages');
    }
};
