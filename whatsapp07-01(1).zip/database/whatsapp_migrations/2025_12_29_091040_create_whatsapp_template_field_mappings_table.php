<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
	    Schema::create('whatsapp_template_field_mappings', function (Blueprint $table) {
		    $table->char('id', 36)->primary();
		    $table->char('organization_id', 36);

		    $table->string('template_name', 255);
		    $table->string('template_language', 10)->nullable();

		    $table->string('template_variable', 100)->nullable();
		    $table->string('crm_module', 100)->nullable();
		    $table->string('crm_field', 100)->nullable();

		    $table->timestamp('created_at')->nullable();
		    $table->timestamp('updated_at')->nullable();

		    $table->foreign('organization_id')
	    ->references('id')
	    ->on('organizations')
	    ->onDelete('cascade');
	    });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('whatsapp_template_field_mappings');
    }
};
