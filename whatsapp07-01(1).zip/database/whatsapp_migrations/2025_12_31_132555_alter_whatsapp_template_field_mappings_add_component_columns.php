<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
	/**
	 * Run the migrations.
	 */
	public function up()
	{
		Schema::table('whatsapp_template_field_mappings', function (Blueprint $table) {
			$table->string('component_type', 20)
	 ->default('body')
	 ->after('template_variable');
			// body | header | button

			$table->integer('button_index')
	 ->nullable()
	 ->after('component_type');
			// 0,1,2...

			$table->integer('button_param_position')
	 ->nullable()
	 ->after('button_index');
			// {{1}}, {{2}}...
		});
	}

	public function down()
	{
		Schema::table('whatsapp_template_field_mappings', function (Blueprint $table) {
			$table->dropColumn([
				'component_type',
				'button_index',
				'button_param_position'
			]);
		});
	}
};
