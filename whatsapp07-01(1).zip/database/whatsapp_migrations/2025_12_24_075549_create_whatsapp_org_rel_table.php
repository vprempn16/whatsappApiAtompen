<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
	    Schema::create('whatsapp_org_rel', function (Blueprint $table) {
		    $table->char('id', 36)->primary();
		    $table->char('organization_id', 36);
		    $table->string('whatsapp_business_id', 255);
		    $table->string('secret_id', 255);
		    $table->timestamp('created_at')->nullable();
		    $table->timestamp('updated_at')->nullable();
	    });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('whatsapp_org_rel');
    }
};
