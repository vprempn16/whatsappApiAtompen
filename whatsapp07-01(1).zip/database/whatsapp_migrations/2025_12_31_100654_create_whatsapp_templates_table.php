<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
	    Schema::create('whatsapp_templates', function (Blueprint $table) {
		    $table->char('id', 36)->primary();
		    $table->char('organization_id', 36);

		    $table->string('template_name', 255);
		    $table->string('language', 20);
		    $table->string('format', 20); // POSITIONAL | NAMED
		    $table->string('status', 50);

		    $table->json('components')->nullable();
		    $table->string('category', 50)->nullable();

		    $table->string('template_id', 255); // Meta template id

		    $table->timestamp('created_at')->nullable();
		    $table->timestamp('updated_at')->nullable();

		    $table->foreign('organization_id')
	    ->references('id')->on('organizations')
	    ->onDelete('cascade');
	    });
    }


    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('whatsapp_templates');
    }
};
