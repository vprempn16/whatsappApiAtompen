<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
	    Schema::create('whatsapp_media', function (Blueprint $table) {
		    $table->char('id', 36)->primary();
		    $table->char('organization_id', 36)->index();
		    $table->string('media_id', 255)->nullable(); // Meta media id
		    $table->string('mime_type', 100)->nullable();
		    $table->string('file_name', 255)->nullable();
		    $table->string('local_path', 255)->nullable();
		    $table->char('created_by', 36)->nullable();
		    $table->timestamp('created_at')->nullable();
                    $table->timestamp('updated_at')->nullable();
	    });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('whatsapp_media');
    }
};
