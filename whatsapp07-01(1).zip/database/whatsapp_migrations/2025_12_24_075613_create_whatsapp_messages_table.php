<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
	    Schema::create('whatsapp_messages', function (Blueprint $table) {
		    $table->char('id', 36)->primary();
		    $table->char('organization_id', 36);
		    $table->string('message_id', 255)->nullable();
		    $table->string('direction', 20);
		    $table->string('type', 50);
		    $table->text('message')->nullable();
		    $table->string('media_url', 255)->nullable();
		    $table->string('status', 50)->nullable();
		    $table->longText('info')->nullable()->after('media_id');

		    $table->char('created_by', 36)->nullable();
		    $table->tinyInteger('deleted')->default(0);
		    $table->timestamp('created_at')->nullable();
		    $table->timestamp('updated_at')->nullable();
	    });


    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('whatsapp_messages');
    }
};
