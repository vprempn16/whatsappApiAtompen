<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up()
    {
        Schema::table('whatsapp_org_rel', function (Blueprint $table) {
            // remove old column
            if (Schema::hasColumn('whatsapp_org_rel', 'secret_id')) {
                $table->dropColumn('secret_id');
            }

            // add new fields
            $table->string('app_id', 255)->after('organization_id');
            $table->string('app_secret', 255)->after('app_id');
            $table->string('phone_number_id', 255)->after('app_secret');
            $table->string('business_id', 255)->after('phone_number_id');
            $table->text('access_token')->after('business_id');
        });
    }

    public function down()
    {
        Schema::table('whatsapp_org_rel', function (Blueprint $table) {
            $table->dropColumn([
                'app_id',
                'app_secret',
                'phone_number_id',
                'business_id',
                'access_token',
            ]);

            $table->string('secret_id', 255)->nullable();
        });
    }
};
