<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
	    Schema::table('whatsapp_template_field_mappings', function (Blueprint $table) {
		    $table->string('module', 100)->nullable()->after('template_language');
	    });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('whatsapp_template_field_mappings', function (Blueprint $table) {
		            $table->dropColumn('module');
        });
    }
};
