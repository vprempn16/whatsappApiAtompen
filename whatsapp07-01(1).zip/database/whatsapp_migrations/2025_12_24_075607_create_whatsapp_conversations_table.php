<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
	Schema::create('whatsapp_conversations', function (Blueprint $table) {
		$table->char('id', 36)->primary();
		$table->char('organization_id', 36);
		$table->string('conversation_id', 255);
		$table->string('phone_number', 255);
		$table->char('contact_id', 36)->nullable();
		$table->string('status', 50)->default('open');
		$table->timestamp('last_message_at')->nullable();
		$table->tinyInteger('deleted')->default(0);
		$table->char('created_by', 36)->nullable();
		$table->timestamp('created_at')->nullable();
		$table->timestamp('updated_at')->nullable();
	});
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('whatsapp_conversations');
    }
};
